let nome = 'New configuration';

console.log(nome);